let player;
let enemies = [];
let gameOver = false;
let score = 0;

function setup() {
  createCanvas(400, 600);
  player = new Car(width / 2 - 25, height / 2 - 45, color(255, 0, 0), color(255, 0, 0)); // Teto vermelho
}

function draw() {
  background(50, 150, 50); // Grama

  drawRoad();

  if (!gameOver) {
    player.update();
    player.show();

    // Gera inimigos
    if (frameCount % 60 === 0) {
      enemies.push(new Car(random(20, width - 70), -100, color(0, 200, 0), color(0, 200, 0))); // Teto verde
    }

    // Atualiza inimigos
    for (let i = enemies.length - 1; i >= 0; i--) {
      enemies[i].moveDown();
      enemies[i].show();

      if (player.hits(enemies[i])) {
        gameOver = true;
      }

      if (enemies[i].y > height) {
        enemies.splice(i, 1);
        score++;
      }
    }

    // Placar
    fill(255);
    textSize(20);
    text("Score: " + score, 10, 30);
  } else {
    // Tela de Game Over
    fill(255, 0, 0);
    textSize(40);
    textAlign(CENTER, CENTER);
    text("Game Over", width / 2, height / 2);
    textSize(20);
    text("Score: " + score, width / 2, height / 2 + 40);
  }
}

function drawRoad() {
  fill(100);
  rect(0, 0, width, height);

  stroke(255);
  strokeWeight(4);
  for (let y = 0; y < height; y += 40) {
    line(width / 2, y, width / 2, y + 20);
  }
}

function keyPressed() {
  if (key === 'a' || key === 'A') {
    player.move(-1);
  } else if (key === 'd' || key === 'D') {
    player.move(1);
  }
}

class Car {
  constructor(x, y, bodyColor, roofColor) {
    this.x = x;
    this.y = y;
    this.w = 50;
    this.h = 90;
    this.bodyColor = bodyColor;
    this.roofColor = roofColor;
    this.speed = 5;
  }

  show() {
    push();
    translate(this.x, this.y);
    noStroke();

    // Corpo principal
    fill(this.bodyColor);
    rect(0, 0, this.w, this.h, 10);

    // Teto (cor diferente)
    fill(this.roofColor);
    rect(10, 20, this.w - 20, this.h - 40, 8);

    // Para-brisa
    fill(30, 144, 255);
    rect(10, 5, this.w - 20, 15, 5);

    // Traseira (vidro traseiro)
    rect(10, this.h - 20, this.w - 20, 15, 5);

    // Lanternas traseiras
    fill(255, 0, 0);
    rect(5, this.h - 5, 10, 5);
    rect(this.w - 15, this.h - 5, 10, 5);

    // Faróis dianteiros
    fill(255, 255, 100);
    rect(5, 0, 10, 5);
    rect(this.w - 15, 0, 10, 5);

    pop();
  }

  update() {
    this.y = height / 2 - this.h / 2;
  }

  move(dir) {
    this.x += dir * this.speed * 10;
    this.x = constrain(this.x, 0, width - this.w);
  }

  moveDown() {
    this.y += 5;
  }

  hits(other) {
    return (
      this.x < other.x + other.w &&
      this.x + this.w > other.x &&
      this.y < other.y + other.h &&
      this.y + this.h > other.y
    );
  }
}